﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace game
{
    public partial class Form1 : Form
    {
        Bitmap MyBK = new Bitmap("BG.png");
        Bitmap MyBK2 = new Bitmap("xx.png");
        Bitmap kk = new Bitmap("pngegg (5).png");
        Timer tt = new Timer();
        int l = 0;
        int ke = 0;
        int lv=0;
        int v = 0;
        int v2 = 1345;
        int f10 = 0;
        int ta = 10;
       
        public class m
        {
            public int x, y;
            public Bitmap im;
            public Graphics g;
        }
        m pnn = new m();
        List<m> L = new List<m>();
        List<m> Lf = new List<m>();
        List<m> L2 = new List<m>();
        List<m> L3 = new List<m>();
        List<m> L3f = new List<m>();
        List<m> L4 = new List<m>();
        List<m> L5 = new List<m>();
        List<m> L6 = new List<m>();
        List<m> L7 = new List<m>();
        List<m> L8 = new List<m>();
        List<m> L9 = new List<m>();
        List<m> L10 = new List<m>();
        List<m> e2 = new List<m>();
        List<m> e3 = new List<m>();
        List<m> h = new List<m>();
        List<m> key = new List<m>();
        List<m> p = new List<m>();
        List<m> pf = new List<m>();
        List<m>w = new List<m>();
        List<m> t = new List<m>();
        List<m> tf = new List<m>();
        public Form1()
        {
            this.WindowState = FormWindowState.Maximized;
            this.MouseClick += Form1_MouseClick;
            this.Paint += Form1_Paint;
            this.KeyDown += Form1_KeyDown;
            this.KeyUp += Form1_KeyUp;
            this.Load += Form1_Load1;
            tt.Tick += Tt_Tick;
            tt.Start();
        }
        int f4 = 0;
        int pt;
        int f11 = 0;
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            f4 = 1;
            f11 = 0;
        }
        int ce = 0;
        int fe2 = 0;
        Bitmap onMemory;
        int ke2 = 0;
        private void Tt_Tick(object sender, EventArgs e)
        {
            if(lv==2&&s>-1350)
            {
                s = s - 10;
                v=v-10;
               L3[0].x = L3[0].x - 10;
                f6 = 1;

            }
            if(lv==2&& L3[0].x>-250&&L3[0].x<30&& L3[0].y>110 && L3[0].y < 150)
            {
            f6 = 1;
            }
            if (lv == 2 && L3[0].x > -250 && L3[0].x < -85 && L3[0].y > 270 && L3[0].y < 320)
            {
                f6 = 1;
            }
            if (lv == 2 && L3[0].x > -250 && L3[0].x < -85 && L3[0].y > 80)
            {
                f6 = 1;
            }
            if (f3 == 1)
                {

                    for (i = 0; i < L.Count; i++)
                    {

                        L[i].x = L[i].x + 5;

                        if (L[i].x < e2[0].x - 150 && L[i].x + 30 > e2[0].x - 150 && L[i].y > 400 && L[i].y < 800 && fe2 == 0)
                        {
                            fe2 = 1;

                            L.Remove(L[i]);
                            break;
                        }
                        if (L[i].x < 700 && L[i].x > 600 && L7[0].y <= L[i].y && L7[0].y + 100 >= L[i].y && fe == 0)
                        {
                            fe = 1;

                            L.Remove(L[i]);
                            break;
                        }
                        if (L[i].x > 1400)
                        {
                            L.Remove(L[i]);
                        }




                    }

                    for (i = 0; i < Lf.Count; i++)
                    {

                        Lf[i].x = Lf[i].x - 5;
                        if (Lf[i].x < 700 && Lf[i].x > 500 && L7[0].y - 100 <= Lf[i].y && L7[0].y + 100 >= Lf[i].y && fe == 0)
                        {
                            fe = 1;
                            Lf.Remove(Lf[i]);

                            break;
                        }
                        if (Lf[i].x > e3[0].x && Lf[i].x < e3[0].x + 50 && Lf[i].y < 300 && Lf[i].y > 100)
                        {
                            Lf.Remove(Lf[i]);
                            fe3 = 1;
                            break;
                        }
                    }

                    // DrawDB(CreateGraphics());

                }
                if (f2 == 1 && f5 == 0)
                {

                    L3[0].y = L3[0].y + a;




                    c++;
                }
                if (f2 == 1 && f5 == 1)
                {

                    L3[0].y = L3[0].y + a;
                    L3[0].x = L3[0].x + 5;



                    c++;
                }
                if (f2 == 1 && f5 == 2)
                {

                    L3[0].y = L3[0].y + a;
                    L3[0].x = L3[0].x - 5;


                    c++;
                }
                if (c == 5)
                {
                    k = 7;
                    kf = 7;
                    a = a * -1;
                }
                if (c == 7)
                {
                    c = 0;
                    f2 = 0;
                    k = 0;
                    kf = 0;
                    f5 = 0;
                }
                if (f6 == 0 && L2[0].x + 30 < L3[0].x + 210 && lv==0 || f6 == 0 && L2[0].x > L3[0].x + 210)
                {

                    L3[0].y = L3[0].y + 5;


                }
                if (ce % 10 == 0)
                {

                    ke++;
                    if (ke == 3)
                    {
                        ke = 0;

                    }
                }
                ce++;
            
            DrawDB(CreateGraphics());
        }
        int k = 0;
        int kf = 0;
        int i;
        int fe = 0;
        int ae2 = 1;
        private void Form1_Load1(object sender, EventArgs e)
        {
            onMemory = new Bitmap(ClientSize.Width, ClientSize.Height);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-1.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-2.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-3.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-4.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-5.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-6.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("j.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("d.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("f3.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);
            
            pnn = new m();
            pnn.im = new Bitmap("down.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3.Add(pnn);

            pnn = new m();
            pnn.im = new Bitmap("l.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            
            L2.Add(pnn);
            ///
            pnn = new m();
            pnn.im = new Bitmap("Untitled-1f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-2f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-3f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-4f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-5f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Untitled-6f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("jf.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("df.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("f3f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("f3f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
            L3f.Add(pnn);
           
            //

           
            
            L2[0].y = 500;
            L2[0].x = 500;
            L3[0].x = 100;
            L3[0].y = 450;
            pnn = new m();
            pnn.im = new Bitmap("c.jpeg");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
           
            L4.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("c2.jpeg");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L5.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("g.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L6.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("w.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L6.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L7.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e2.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L7.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e3.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L7.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("s.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L8.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Ladder1.png");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L9.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("TombStone (2).png");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L10.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("ArrowSign.png");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L10.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("Skeleton.png");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            L10.Add(pnn);
            //
            pnn = new m();
            pnn.im = new Bitmap("e21.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e22.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);

            pnn = new m();
            pnn.im = new Bitmap("e23.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e24.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e25.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e26.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e27.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e28.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e29.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e30.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e31.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e32.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e2.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e41.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e42.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e43.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e44.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e45.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e46.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e47.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("e48.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            e3.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("h.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            h.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("h2.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            h.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("h3.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            h.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("key.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            key.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("plane2.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            p.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("plan.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            p.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("plan3.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            p.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("plan4.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            p.Add(pnn);
            p.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("plan3f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            p.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("plan4f.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            p.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("17.png");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            w.Add(pnn);
            p.Add(pnn);
            pnn = new m();
            pnn.im = new Bitmap("tank.bmp");
            pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));

            t.Add(pnn);
            t[0].y = 120;
            t[0].x = 300;
            p[0].x = 750;
            p[0].y = -200;
            e3[0].x = 500;
            e2[0].x = 1000;
            L5[0].x = 500;
            L5[0].y = 500;
            DrawDB(CreateGraphics());
        }
        int f2 = 0;
        int a = 0;
        int c = 0;
        int f3 = 0;
        int f5 = 0;
        int f6=0;
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Right)
            {

                L3[0].x = L3[0].x + 10;
                k++;
                f5 = 1;
                l = 0;
                if (k >= 6)
                {
                    k = 0;
                }
                if (k == -1)
                {
                    k = 5;
                }
                if (lv == 2 && f10 == 1)
                {
                    p[0].x = p[0].x + 10;
                   
                    pt = 2;
                }
                f11 = 1;
            }
            if (e.KeyCode == Keys.Left)
            {
                l = 1;
                f5 = 2;
                L3[0].x = L3[0].x - 10;
                kf--;
                if (kf >= 6)
                {
                    kf = 0;
                }
                if (kf == -1)
                {
                    kf = 5;
                }
                if (lv == 2 && f10 == 1)
                {
                    p[0].x = p[0].x - 10;
                    pt = 5;
                }
                f11 = 2;

            }
            if (e.KeyCode == Keys.Up)
            {
                
                    k = 6;
                
                f2 = 1;
                a = -10;
                //k = 6;
                
                    kf = 6;
                if (lv == 2 && f10 == 1&&f11==0)
                {
                    p[0].y = p[0].y - 10;
                }
                if (lv == 2 && f10 == 1 && f11 == 1)
                {
                    p[0].y = p[0].y - 15;
                    p[0].x = p[0].x + 10;
                    pt = 2;
                }
                if (lv == 2 && f10 == 1 && f11 == 2)
                {
                    p[0].y = p[0].y - 15;
                    p[0].x = p[0].x - 10;
                    pt = 5;
                }
            }
            if (e.KeyCode == Keys.Space)
            {
                f3 = 1;
                if (l == 0&&f10==0)
                {
                    k = 8;
                    pnn = new m();
                    pnn.im = new Bitmap("f2.bmp");
                    pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
                    pnn.y = L3[0].y;
                    pnn.x = L3[0].x + 100;
                    L.Add(pnn);
                }
                //
                if (l == 1 && f10 == 0)
                {
                    kf = 8;
                    pnn = new m();
                    pnn.im = new Bitmap("f2f.bmp");
                    pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
                    pnn.y = L3f[0].y;
                    pnn.x = L3f[0].x - 100;
                    Lf.Add(pnn);
                }
                if (lv == 2 && f10 == 1)
                {
                    pnn = new m();
                    pnn.im = new Bitmap("b2.bmp");
                    pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
                    pnn.y = p[0].y+50;
                    pnn.x = p[0].x+ v;
                     pf.Add(pnn);

                }
            }
            if (e.KeyCode == Keys.W)
            {
                if(L3[0].x>800&& L3[0].x < 940)
                {
                    f6 = 1;
                    L3[0].y = L3[0].y - 10;
                    L3f[0].y = L3f[0].y - 10;
                }
                if (L3[0].x > -185 && L3[0].x < -120 && lv==2&& L3[0].y >55)
                {
                    f6 = 1;
                    L3[0].y = L3[0].y - 10;
                    L3f[0].y = L3f[0].y - 10;
                }
            }
            if (e.KeyCode == Keys.S)
            {
                if (L3[0].x > 800 && L3[0].x < 940 )
                {
                    f6 = 1;
                    L3[0].y = L3[0].y + 10;
                    L3f[0].y = L3f[0].y + 10;
                }
                if (L3[0].x > -185 && L3[0].x < -120 && lv == 2 && L3[0].y > 55)
                {
                    f6 = 1;
                    L3[0].y = L3[0].y + 10;
                    L3f[0].y = L3f[0].y + 10;
                }
            }

            if (e.KeyCode == Keys.Enter)
            {
                if(f10==1)
                {
                    f10 = 0;
                    p[0].x = 750;
                    p[0].y = -200;
                    k = 9;
                }
                if(L3[0].y<120&& L3[0].x>-120&& L3[0].x < 100)
                {
                    f10 = 1;
                    pt = 1;
                }
                
            }
            if (f3 == 1)
            {
                if (l == 0)
                {
                    for (i = 0; i < L.Count; i++)
                    {
                        L[i].x = L[i].x + 5;
                        // DrawDB(CreateGraphics());
                    }
                }
                if (l == 1)
                {
                    for (i = 0; i < Lf.Count; i++)
                    {
                        Lf[i].x = Lf[i].x - 5;
                        // DrawDB(CreateGraphics());
                    }
                }
            }
           // DrawDB(CreateGraphics());
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            DrawDB(CreateGraphics());
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            //throw new NotImplementedException();
        }
        void DrawDB(Graphics g)
        {
            Graphics g2 = Graphics.FromImage(onMemory);
           
            DrawScene(g2);
            g.DrawImage(onMemory, 0, 0);

        }
        int a3 = 0;
        int a4 = 10;
        int ke3 = 0;
        int fe3 = 0;
        int hf = 0;
        int kff = 0;
        int s = 0;
        int gk = 0;
        int mf = 0;
        int mk = 0;
        void DrawScene(Graphics g)
        {

            g.Clear(Color.White);
            g.DrawImage(MyBK, s, 0, 2 * ClientSize.Width, ClientSize.Height);

            if (hf < 3)
            {
                g.DrawImage(h[hf].im, -160, -100);
            }
            if (L3[0].x > 1000 && L3[0].y < 90)
            {

                kff = 1;
            }
            if (kff == 1)
            {
                g.DrawImage(key[0].im, -80, -100);
            }
            L4[0].y = 0;
            L4[0].x = 0 + v;
            g.DrawImage(L10[2].im, 50 + v, 640);
            g.DrawImage(L10[1].im, L7[0].x + 330, L7[0].y + 335);
            if (fe3 == 0)
            {
                g.DrawImage(e3[ke3].im, e3[0].x + v, 290);
                if (L3[0].y < 300 && L3[0].y > 100)
                {
                    if (e3[0].x < 800)
                    {
                        e3[0].x = e3[0].x + 5;
                    }
                    ke3++;
                    if (e3[0].x + 50 == L3[0].x)
                    {
                        g.DrawImage(e3[7].im, e3[0].x, 290);
                        e3[0].x = 500;
                        ke3 = 0;
                        L3[0].x = 100;
                        L3[0].y = 300;
                        hf++;
                    }
                }
                else
                {
                    ke3 = 0;
                }
                if (ke3 > 6)
                {
                    ke3 = 4;
                }
            }
            else
            {
                g.DrawImage(L10[0].im, e3[0].x + 200 + v + 50, 430);
            }
            if (fe2 == 0)
            {
                if (ke2 == 12)
                {
                    ke2 = 0;
                }
                if (ke2 == -1)
                {
                    ke2 = 11;
                }
                g.DrawImage(e2[ke2].im, e2[0].x - 150, 460);

                if (L3[0].x + 10 + 50 > e2[0].x - 150 && L3[0].x - 10 + 50 < e2[0].x - 150)
                {
                    L3[0].x = 100;
                    L3[0].y = 300;
                    hf++;
                }
                if (e2[0].x < 520 || e2[0].x - 150 > 860)
                {
                    ae2 = ae2 * -1;
                }
                e2[0].x = e2[0].x - (ae2 * 10);
                //e2[0].x = 800;

                //e2[0].x = e2[0].x - ae2;
                ke2 = ke2 + (ae2);
            }
            else
            {
                g.DrawImage(L10[0].im, e2[0].x + 50 + v, 620);
            }
            for (i = 0; i < 23; i++)
            {
                g.DrawImage(L4[0].im, L4[0].x, L4[0].y);
                L4[0].y = L4[0].y + 30;
            }
            // g.DrawImage(Bitmap("f2f.bmp", L4[0].x, L4[0].y);
            for (i = 0; i < 50; i++)
            {
                g.DrawImage(L4[0].im, L4[0].x, L4[0].y);
                L4[0].x = L4[0].x + 30;
            }
            L4[0].y = 0;
            L4[0].x = 0 + v;
            for (i = 0; i < 100; i++)
            {
                g.DrawImage(L4[0].im, L4[0].x, L4[0].y);
                L4[0].x = L4[0].x + 30;
            }
            L4[0].y = 0;
            L4[0].x = 1345 + v;
            for (i = 0; i < 10; i++)
            {
                g.DrawImage(L4[0].im, L4[0].x, L4[0].y);
                L4[0].y = L4[0].y + 30;
            }
            L4[0].y = 500;
            L4[0].x = 1345 + v;
            for (i = 0; i < 10; i++)
            {
                g.DrawImage(L4[0].im, L4[0].x, L4[0].y);
                L4[0].y = L4[0].y + 30;
            }
            w[0].x = 1500 + v;
            for (i = 0; i < 9; i++)
            {
                g.DrawImage(w[0].im, w[0].x, 670);
                w[0].x = w[0].x + 130;
            }
            L5[0].x = 570 + v;
            L5[0].y = 500;
            for (i = 0; i < 30; i++)
            {
                g.DrawImage(L5[0].im, L5[0].x, L5[0].y);
                L5[0].x = L5[0].x + 30;
            }

            L5[0].x = 570 + v;
            L5[0].y = 500;
            for
                (i = 0; i < 25; i++)
            {
                g.DrawImage(L5[0].im, L5[0].x, L5[0].y);
                L5[0].x = L5[0].x + 30;
            }
            L5[0].x = 570 + v;
            L5[0].y = 299;
            for (i = 0; i < 35; i++)
            {
                g.DrawImage(L5[0].im, L5[0].x, L5[0].y);
                L5[0].x = L5[0].x + 30;
            }

            L7[0].x = 570 + v;
            L7[0].x = 300;
            g.DrawImage(L2[0].im, L2[0].x + v, L2[0].y + a3);
            // g.DrawImage(L7[0].im, L7[0].x, L7[0].y);
            g.DrawImage(L2[0].im, L2[0].x + 30 + v, L2[0].y + a3);
            a3 = a3 + a4;
            if (L2[0].y + a3 >= 700 || L2[0].y + a3 <= 80)
            {
                a4 = a4 * -1;
            }
            if (L3[0].x < L2[0].x - 150 && L3[0].x + 250 > L2[0].x + 30 && L3[0].y + 200 <= L2[0].y + a3 && L3[0].y + 200 + 200 >= L2[0].y + a3 || L3f[0].x < L2[0].x - 150 && L3f[0].x + 300 > L2[0].x + 30 && L3f[0].y + 200 <= L2[0].y + a3 && L3f[0].y + 200 + 200 >= L2[0].y + a3 && lv == 0)
            {
                L3[0].y = L2[0].y + a3 - 220;
                L3f[0].y = L2[0].y + a3 - 220;
                f6 = 1;

            }
            else
            {
                f6 = 0;
            }
            if (L3[0].x < L2[0].x - 150 && L3[0].x + 250 > L2[0].x + 30 && L3[0].y + 250 == L2[0].y + a3 || L3f[0].x < L2[0].x - 150 && L3f[0].x + 250 > L2[0].x + 30 && L3f[0].y + 250 == L2[0].y + a3 && lv == 0)
            {
                L3[0].y = L2[0].y + a3 - 220;
                L3f[0].y = L2[0].y + a3 - 220;
                f6 = 1;
            }
            else
            {
                f6 = 0;
            }

            for (i = 0; i < L.Count; i++)
            {
                g.DrawImage(L[i].im, L[i].x, L[i].y);
            }

            for (i = 0; i < Lf.Count; i++)
            {
                g.DrawImage(Lf[i].im, Lf[i].x, Lf[i].y);
            }

            if (L3[0].y >= 480 && lv == 0)
            {
                f6 = 1;
            }
            if (L3f[0].y >= 480 && lv == 0)
            {
                f6 = 1;
            }
            L6[0].x = 1060 + v;
            L6[0].y = 239;
            if (kff == 0)
            {
                g.DrawImage(L6[0].im, L6[0].x, L6[0].y);
            }
            else
            {
                if (L3[0].y > 90 && L3[0].y < 300 && L3[0].x > 1000)
                {
                    lv = 2;
                }
                else
                {
                    g.DrawImage(L6[0].im, L6[0].x - 30, L6[0].y);
                }
            }
            L6[1].x = 1030 + v;
            L6[1].y = 78;
            if (kff == 0)
            {
                g.DrawImage(L6[1].im, L6[1].x, L6[1].y);
            }
            L3f[0].x = L3[0].x;
            L3f[0].y = L3[0].y;
            if (L3[0].x > 320 && L3[0].y == 290 && lv == 0 || L3[0].x > 320 && L3[0].y == 85 && lv == 0)
            {
                f6 = 1;
            }
            if (L3[0].x > 850 && L3[0].x < 940 && lv == 0)
            {
                f6 = 1;
            }
            L7[0].x = 700 + v;
            L7[0].y = 78;
            if (fe == 0)
            {
                if (ke == 2)
                {
                    g.FillRectangle(Brushes.Red, 30, L7[0].y + 175, 900, 5);
                    if (L3[0].y <= 180 && L3[0].y >= 70 && L3[0].x > 0 && L3[0].x < L7[0].x)
                    {
                        L3[0].x = 100;
                        L3[0].y = 300;
                        hf++;
                    }
                }
                g.DrawImage(L7[ke].im, L7[0].x, L7[0].y);
            }
            else
            {
                g.DrawImage(L10[0].im, L7[0].x + 150, L7[0].y + 150);
            }


            g.DrawImage(L8[0].im, L7[0].x - 300, L7[0].y + 200);
            int a7 = 0;
            for (i = 0; i < 37; i++)
            {
                g.DrawImage(L9[0].im, 900 + v, L7[0].y + a7 + 50);
                g.DrawImage(L9[0].im, 1200 + v, L7[0].y + a7 + 50);
                a7 = a7 + 10;
            }


            if (L3[0].x >= L7[0].x - 350 && L3[0].x < L7[0].x - 220 && L3[0].y > 280 && L3[0].y < 300)
            {
                L3[0].x = 100;
                L3[0].y = 300;
                hf++;
            }
            //ke++;
            if (f10 == 0)
            {
                if (l == 0)
                {
                    g.DrawImage(L3[k].im, L3[0].x, L3[0].y);
                }
                if (l == 1)
                {
                    g.DrawImage(L3f[kf].im, L3f[0].x, L3f[0].y);
                }
                // g.FillRectangle(Brushes.Red, 30,100, p[0].x + v, p[0].y-50);
                g.DrawImage(p[0].im, p[0].x + v, p[0].y);
            }
            else
            {
                g.FillRectangle(Brushes.Red, p[0].x - 650 + gk, p[0].y + 350, 150 - mf, 20);
                g.DrawImage(p[pt].im, p[0].x + v, p[0].y);
                if (l == 0)
                {
                    pt = 4;
                    gk = 0;
                }
                if (l == 1)
                {
                    pt = 6;
                    gk = 50;
                }
                if (p[0].x > 900)
                {
                    p[0].y = p[0].y + 5;
                }

            }
            
            for (i = 0; i < pf.Count; i++)
            {
                pf[i].y = pf[i].y + 10;
                g.DrawImage(pf[i].im, pf[i].x, pf[i].y);
                if (pf[i].x < t[0].x + 150 && pf[i].x > t[0].x - 100 && pf[i].y > 55 && pf[i].y < 70)
                {
                    pf.Remove(pf[i]);
                    mk = mk + 50;
                }
            }

            if (lv == 2 && s <= -1350 && mk <= 350)
            {
                g.FillRectangle(Brushes.Red, t[0].x + 600, t[0].y + 350, 350 - mk, 20);
                g.DrawImage(t[0].im, t[0].x, t[0].y);
                t[0].x = t[0].x - ta;
                if (t[0].x == -450 || t[0].x > 300)
                {
                    ta = ta * -1;
                }
                if (ce % 20 == 0)
                {
                    pnn = new m();
                    pnn.im = new Bitmap("bu.bmp");
                    pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
                    pnn.x = t[0].x;
                    pnn.y = 0;
                    tf.Add(pnn);
                }
            }
           
            for (i = 0; i < tf.Count; i++)
            {

                g.DrawImage(tf[i].im, tf[i].x, tf[i].y);

                tf[i].y = tf[i].y - 10;
                if (p[0].y < tf[i].y && p[0].y + 30 > tf[i].y && p[0].x > tf[i].x + 1320 && p[0].x < tf[i].x + 1460)
                {
                    tf.Remove(tf[i]);
                    mf = mf + 50;
                }

            }
            if (L3[0].x > -95 && L3[0].y > 465 && lv == 2)
            {
                hf++;
              L3[0].x=-150;
              L3[0].y=290;
                k = 0;
            }
            if (mf == 150 ||p[0].y>80&&p[0].y<90)
            {
                p[0].x = 750;
                p[0].y = -200;
                hf++;
                mf = 0;
               

            }
            if (hf == 3)
            {
                g.Clear(Color.White);
                g.DrawImage(kk, 0, 0, ClientSize.Width, ClientSize.Height);
            }
            if (s <= -1350 && mk >= 350)
            {
                g.Clear(Color.White);
                g.DrawImage(MyBK2, 0, 0, ClientSize.Width, ClientSize.Height);
                hf = 0;
            }
        }
    }
}
